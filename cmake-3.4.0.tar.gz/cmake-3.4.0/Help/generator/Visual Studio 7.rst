Visual Studio 7
---------------

Deprected.  Generates Visual Studio .NET 2002 project files.

.. note::
  This generator is deprecated and will be removed
  in a future version of CMake.  It will still be
  possible to build with VS 7.0 tools using the
  :generator:`NMake Makefiles` generator.

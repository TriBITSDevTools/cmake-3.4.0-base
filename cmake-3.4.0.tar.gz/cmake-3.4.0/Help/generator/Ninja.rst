Ninja
-----

Generates build.ninja files.

A build.ninja file is generated into the build tree.  Recent versions
of the ninja program can build the project through the "all" target.
An "install" target is also provided.

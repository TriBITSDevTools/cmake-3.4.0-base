.. cmake-module:: ../../Modules/FindSDL_ttf.cmake
